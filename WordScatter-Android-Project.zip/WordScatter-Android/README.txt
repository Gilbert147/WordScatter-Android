# Word Scatter — Android project starter

This project contains the original Word Scatter game in `www/index.html`, wrapped for Android with Capacitor.

## Important
- The game source is preserved as supplied; no gameplay or visual redesign has been made.
- This ZIP is a ready-to-build project starter, **not a compiled APK**.
- Android APK compilation requires a Windows/macOS/Linux computer with Node.js and Android Studio installed.

## Build on Windows

1. Install Node.js LTS and Android Studio.
2. Extract this ZIP to a normal folder, for example `C:\WordScatter-Android`.
3. Open Command Prompt in that folder.
4. Run these commands one at a time:

   ```bat
   npm install
   npm install @capacitor/android
   npx cap add android
   npx cap sync android
   npx cap open android
   ```

5. Android Studio opens the project. Wait for Gradle sync to finish.
6. To create an APK, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Android Studio will show a notification with a link to the generated APK.

## App identity
- App name: Word Scatter
- Android application ID: `com.wordscatter.game`

## Project contents
- `www/index.html` — original game
- `package.json` — Node/Capacitor project settings
- `capacitor.config.ts` — Android wrapper configuration

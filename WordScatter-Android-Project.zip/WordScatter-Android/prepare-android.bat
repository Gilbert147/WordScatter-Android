@echo off
echo Installing project dependencies...
npm install
if errorlevel 1 goto error
echo Installing Android platform...
npm install @capacitor/android
if errorlevel 1 goto error
echo Creating Android project...
npx cap add android
if errorlevel 1 goto error
echo Syncing Word Scatter...
npx cap sync android
if errorlevel 1 goto error
echo Opening Android Studio...
npx cap open android
goto end
:error
echo.
echo A command failed. Read the error above before continuing.
:end
pause

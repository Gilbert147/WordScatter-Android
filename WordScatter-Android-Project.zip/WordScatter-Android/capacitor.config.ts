import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.wordscatter.game',
  appName: 'Word Scatter',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
